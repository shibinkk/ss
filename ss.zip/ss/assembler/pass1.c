#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void main()
{
	char opcode[10],operand[10],label[10],code[10],mnemonic[10];
	int locctr,start,length;
	FILE *fp1,*fp2,*fp3,*fp4,*fp5,*fp6;
	
	fp1=fopen("input.txt","r");
	fp2=fopen("optab.txt","r");
	fp3=fopen("symtab.txt","w");
	fp4=fopen("inter.txt","w");
	fp5=fopen("length.txt","w");
	//fp6=fopen("start.txt","w");
	
	fscanf(fp1,"%s\t%s\t%s",label,opcode,operand);
	
	if(strcmp(opcode,"START")==0)
	{
		start=atoi(operand);
		locctr=start;
		fprintf(fp4,"\t    %s\t%s\t%s\n",label,opcode,operand);
		fscanf(fp1,"%s\t%s\t%s",label,opcode,operand);
	}
	else
	{
		locctr=0;
	}
	//fprintf(fp6,"%d",start);
	while(strcmp(opcode,"END")!=0)
	{
		fprintf(fp4,"%d\t",locctr);
		if(strcmp(label,"*")!=0)
		{
			fprintf(fp3,"%s\t%d\n",label,locctr);
		}
		fscanf(fp2,"%s\t%s",code,mnemonic);
		while(strcmp(code,"END")!=0)
		{
			if(strcmp(opcode,code)==0)
			{
				locctr+=3;
				break;
			}
			fscanf(fp2,"%s\t%s",code,mnemonic);
		}
		if(strcmp(opcode,"WORD")==0)
		{
			locctr+=3;
		}
		if(strcmp(opcode,"RESW")==0)
		{
			locctr+=(3*(atoi(operand)));
		}
		if(strcmp(opcode,"RESB")==0)
		{
			locctr+=(atoi(operand));
		}
		if(strcmp(opcode,"BYTE")==0)
		{
			++locctr;
		}
		fprintf(fp4,"%s \t %s \t %s\n",label,opcode,operand);
		fscanf(fp1,"%s\t%s\t%s",label,opcode,operand);
		rewind(fp2);
	}
	fprintf(fp4,"%c\t%s\t%s\t%s\n",'*',label,opcode,operand);
	length=locctr-start;
	printf("the length of the code :%d \n",length);
	fprintf(fp5,"%d",length);
	fprintf(fp3,"END\t *\n");
	fclose(fp1);
	fclose(fp2);
	fclose(fp3);
	fclose(fp4);
	fclose(fp5);
	//fclose(fp6);
	
 }
